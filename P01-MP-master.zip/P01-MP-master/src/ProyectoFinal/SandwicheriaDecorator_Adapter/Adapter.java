package SandwicheriaDecorator_Adapter;
public interface Adapter{

public String getDescripcion();

public double costo();

}
