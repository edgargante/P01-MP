package SandwicheriaDecorator_Adapter;
public class SandwichDePollo extends Sandwich{

}
