package SandwicheriaDecorator_Adapter;
public class SandwichDeSalchicha extends Sandwich{

}
