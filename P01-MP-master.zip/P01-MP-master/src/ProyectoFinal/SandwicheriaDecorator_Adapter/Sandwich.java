package SandwicheriaDecorator_Adapter;
public interface Sandwich{

  public double getCost();

  public String getDescription();
}
