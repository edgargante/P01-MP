package iterator;
public class Nodo {
	Ingrediente i;
	Nodo sig, ant;
	public Nodo(Ingrediente n){
		i=n;
	}
}
