package iterator;
import java.util.Iterator;

public interface Menu{

	public Iterator iterator();

	public void imprime();


}
