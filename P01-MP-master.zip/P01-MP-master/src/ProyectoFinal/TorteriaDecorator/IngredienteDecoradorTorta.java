
package TorteriaDecorator;
public abstract class IngredienteDecoradorTorta extends Torta {

  public abstract String getDescripcion();

}
