package TorteriaDecorator;
public class TortaSimple extends Torta {

    public TortaSimple() {
         descripcion = "Torta Simple";
    }

    public double costo() {
        return 50.00;
    }

}
