package TorteriaDecorator;
public class TortaIntegral extends Torta {

  public TortaIntegral() {
    descripcion = "Torta Integral";
  }

  public double costo() {
    return 80.00;
  }

}
