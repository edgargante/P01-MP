package TorteriaDecorator;
public abstract class Torta {

  String descripcion = "Torta no identificada.";

  public String getDescripcion() {
    return descripcion;
  }

  public abstract double costo();

}
